package bg.tu_varna.sit.a1.f22621632;

public class Application {
    public static void main(String[] args) {

    }
}
